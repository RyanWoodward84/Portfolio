
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "simple.h"


#define FPU_FACTOR 2048
// 2^11 = 2048
#define SHIFT 11

#define p00 src->data[y0 * src->width + x0]
#define p01 src->data[(y0 + 1) * src->width + x0]
#define p10 src->data[y0 * src->width + (x0 + 1)]
#define p11 src->data[(y0 + 1) * src->width + (x0 + 1)]

void scale(SIMPLE_Image* src, SIMPLE_Image* dst, float scale_factor) {
  const int dst_width_scaled = src->width * scale_factor;
  const int dst_height_scaled = src->height * scale_factor;
  const int x_ratio_scaled = (int)((double)FPU_FACTOR * src->width / dst_width_scaled + 0.5);    // FPU_FACTOR * src->width / dst_width_scaled;
  const int y_ratio_scaled = (int)((double)FPU_FACTOR * src->height / dst_height_scaled + 0.5);  // FPU_FACTOR * src->height / dst_height_scaled;

  int x, y;
  for (y = 0; y < dst->height; y++) {
    int sy = y * y_ratio_scaled;
    int y0 = sy >> SHIFT;
    int fracy = sy - (y0 << SHIFT);

    for (x = 0; x < dst->width; x++) {
      int sx = x * x_ratio_scaled;
      int x0 = sx >> SHIFT;
      int fracx = sx - (x0 << SHIFT);

      dst->data[(y * dst->width) + x] =
          ((
               p00 * (FPU_FACTOR - fracx) * (FPU_FACTOR - fracy) +
               p01 * (FPU_FACTOR - fracx) * fracy +
               p10 * fracx * (FPU_FACTOR - fracy) +
               p11 * fracx * fracy +
               (FPU_FACTOR * FPU_FACTOR / 2)) >>
           (2 * SHIFT));
    }
  }
}


int main(int argc, char** argv) {
  if (argc != 4) {
    printf("Usage: ./scale input.simple output.simple 0.5\n");
    return EXIT_FAILURE;
  }
  char* src_file = argv[1];
  char* dst_file = argv[2];
  float scale_factor = atof(argv[3]);

  SIMPLE_Image* src = SIMPLE_open(src_file);
  if (src == NULL) {
    return EXIT_FAILURE;
  }
  SIMPLE_Image* dst = SIMPLE_new(
      src->width * scale_factor,
      src->height * scale_factor);

  scale(src, dst, scale_factor);

  int status = SIMPLE_save(dst, dst_file);
  SIMPLE_destroy(src);
  SIMPLE_destroy(dst);
  return status;
}
