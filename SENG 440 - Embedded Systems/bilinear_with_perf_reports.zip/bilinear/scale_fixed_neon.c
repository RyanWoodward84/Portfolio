
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "simple.h"

/*
Since S3C440A CPU does not have any SIMD extension, we cannot perform any vectorized implementaion
using NEON. We can only perform such optimization which will reduce numbers of instruction exectured,
replace inefficient instruction with their efficient version or reduce memory usage to decrease cache miss rate.
*/


#include <arm_neon.h>
#define Q_BITS (11u)
#define Q_MAX ((uint32_t)(1<<Q_BITS))
#define Q_FLOAT_TO_FIXED(a) ((uint32_t)((float)a*Q_MAX))
#define Q_10 Q_MAX

void scale(SIMPLE_Image* src, SIMPLE_Image* dst, float scale_factor)
{
  int32_t i, j, k=0;
  int32_t scale = Q_FLOAT_TO_FIXED(1.0f / scale_factor);
  const int32x2_t v_const0 = {1, -1};
  const int32x2_t v_const1 = {Q_10, 0};

  for(i = 0; i < dst->height; i++)
  {
    int32_t y = (scale * i) >> Q_BITS;
    int32_t yfrac = (scale * i) - (y << Q_BITS);
    int32_t i_yfrac = Q_10 - yfrac;

    for(j = 0; j < dst->width; j++)
    {
      int32_t x = (scale * j) >> Q_BITS;
      int32_t xfrac = (scale * j) - (x << Q_BITS);
      int32_t index = x + y * src->width;

      int32x2_t v_src0, v_src1;
      int32x2_t v_weight0, v_weight1;
      int32_t gray;

      // Vector load from memory
      v_src0[0] = src->data[index    ];
      v_src0[1] = src->data[index + 1];
      v_src1[0] = src->data[index + src->width    ];
      v_src1[1] = src->data[index + src->width + 1];

      // Vector load with constant
      //v_weight0[0] = xfrac;
      //v_weight0[1] = xfrac;
      v_weight0 = vld1_dup_s32(&xfrac);
      //v_weight1[0] = xfrac;
      //v_weight1[1] = xfrac;
      v_weight1 = vld1_dup_s32(&xfrac);

      // Vector multiply
      //v_weight0[0] = v_weight0[0] * v_const0[0];
      //v_weight0[1] = v_weight0[1] * v_const0[1];
      v_weight0 = vmul_s32(v_weight0, v_const0);
      //v_weight1[0] = v_weight1[0] * v_const0[0];
      //v_weight1[1] = v_weight1[1] * v_const0[1];
      v_weight1 = vmul_s32(v_weight1, v_const0);

      // Vector substract
      //v_weight0[0] = v_const1[0] - v_weight0[0];
      //v_weight0[1] = v_const1[1] - v_weight0[1];
      v_weight0 = vsub_s32(v_const1, v_weight0);
      //v_weight1[0] = v_const1[0] - v_weight1[0];
      //v_weight1[1] = v_const1[1] - v_weight1[1];
      v_weight1 = vsub_s32(v_const1, v_weight1);

      // Vector multiply
      //v_weight0[0] = v_weight0[0] * i_yfrac;
      //v_weight0[1] = v_weight0[1] * i_yfrac;
      v_weight0 = vmul_n_s32(v_weight0, i_yfrac);
      //v_weight1[0] = v_weight1[0] * yfrac;
      //v_weight1[1] = v_weight1[1] * yfrac;
      v_weight1 = vmul_n_s32(v_weight1, yfrac);

      // Vector multiply
      //v_src0[0] = v_src0[0] * v_weight0[0];
      //v_src0[1] = v_src0[1] * v_weight0[1];
      v_src0 = vmul_s32(v_src0, v_weight0);
      //v_src1[0] = v_src1[0] * v_weight1[0];
      //v_src1[1] = v_src1[1] * v_weight1[1];
      v_src1 = vmul_s32(v_src1, v_weight1);

      // Vector accross vector
      //gray = v_src0[0] + v_src1[0] + 
      //     + v_src0[1] + v_src1[1];
      v_src0 = vadd_s32(v_src0, v_src1);
      gray = vget_lane_s32(v_src0, 0) +
           + vget_lane_s32(v_src0, 1);
      
      gray >>= (Q_BITS+Q_BITS);

      dst->data[k++] = (uint32_t)gray;
    }
  }
}


int main(int argc, char** argv) {
  if (argc != 4) {
    printf("Usage: ./scale input.simple output.simple 0.5\n");
    return EXIT_FAILURE;
  }
  char* src_file = argv[1];
  char* dst_file = argv[2];
  float scale_factor = atof(argv[3]);

  SIMPLE_Image* src = SIMPLE_open(src_file);
  if (src == NULL) {
    return EXIT_FAILURE;
  }
  SIMPLE_Image* dst = SIMPLE_new(
      src->width * scale_factor,
      src->height * scale_factor);

  scale(src, dst, scale_factor);

  int status = SIMPLE_save(dst, dst_file);
  SIMPLE_destroy(src);
  SIMPLE_destroy(dst);
  return status;
}
