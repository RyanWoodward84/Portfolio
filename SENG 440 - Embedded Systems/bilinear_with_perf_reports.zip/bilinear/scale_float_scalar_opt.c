
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "simple.h"

/*
Since S3C440A CPU does not have any SIMD extension, we cannot perform any vectorized implementaion
using NEON. We can only perform such optimization which will reduce numbers of instruction exectured,
replace inefficient instruction with their efficient version or reduce memory usage to decrease cache miss rate.
*/

/*
In this implementation few optimizations happened:
- moved y and yfrac calculation to outer loop since it isn't correlated with variable i
- removed double because this CPU has only 32-bit register and to make algorithm faster,
  we must use only native types (such types that fit into CPU registers without any transform)
  because otherwise compiler will add many instruction that must handle 64-bit wide calculations.
- uint8_t type has been also removed from calculations as it also isn't native type for 32-bit architecture.
- for loops replaced by while(). Usually while loops are the fastests especially when condition inside
  them is as simple as possible. That's why I switch to iterating from the end of image.
*/
void scale(SIMPLE_Image* src, SIMPLE_Image* dst, float scale_factor)
{
  uint32_t i = dst->height, k = dst->height*dst->width-1;
  uint32_t j;
  float scale = 1.0f / scale_factor;

  while(i--)
  {
    uint32_t y = (uint32_t)(scale * i);
    float yfrac = scale * i - y;
    j = dst->width;

    while(j--)
    {
      uint32_t x = (uint32_t)(scale * j);
      float xfrac = scale * j - x;
      float i_xfrac = 1.0f - xfrac;
      float i_yfrac = 1.0f - yfrac;
      uint32_t index = x + y * src->width;

      uint32_t A = src->data[index];
      uint32_t B = src->data[index + 1];
      uint32_t C = src->data[index + src->width];
      uint32_t D = src->data[index + src->width + 1];

      uint32_t gray = (uint32_t)(A * i_xfrac * i_yfrac +
                    + B * xfrac * i_yfrac +
                    + C * yfrac * i_xfrac +
                    + D * xfrac * yfrac);
      dst->data[k--] = (uint8_t)gray;
    }
  }
}


int main(int argc, char** argv) {
  if (argc != 4) {
    printf("Usage: ./scale input.simple output.simple 0.5\n");
    return EXIT_FAILURE;
  }
  char* src_file = argv[1];
  char* dst_file = argv[2];
  float scale_factor = atof(argv[3]);

  SIMPLE_Image* src = SIMPLE_open(src_file);
  if (src == NULL) {
    return EXIT_FAILURE;
  }
  SIMPLE_Image* dst = SIMPLE_new(
      src->width * scale_factor,
      src->height * scale_factor);

  scale(src, dst, scale_factor);

  int status = SIMPLE_save(dst, dst_file);
  SIMPLE_destroy(src);
  SIMPLE_destroy(dst);
  return status;
}
