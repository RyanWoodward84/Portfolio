
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "simple.h"

/*
Since S3C440A CPU does not have any SIMD extension, we cannot perform any vectorized implementaion
using NEON. We can only perform such optimization which will reduce numbers of instruction exectured,
replace inefficient instruction with their efficient version or reduce memory usage to decrease cache miss rate.
*/

void scale(SIMPLE_Image* src, SIMPLE_Image* dst, float scale_factor)
{
  uint32_t i, j;
  uint32_t k = 0;
  double scale = 1.0f / scale_factor;

  for(i = 0; i < dst->height; i++)
  {
    for(j = 0; j < dst->width; j++)
    {
      uint32_t x = (uint32_t)(scale * j);
      uint32_t y = (uint32_t)(scale * i);

      float xfrac = ((double)scale * j) - x;
      float yfrac = ((double)scale * i) - y;

      uint32_t index = x + y * src->width;

      uint8_t A = src->data[index];
      uint8_t B = src->data[index + 1];
      uint8_t C = src->data[index + src->width];
      uint8_t D = src->data[index + src->width + 1];

      uint8_t gray = (uint8_t)(A * (1.0f-xfrac) * (1.0f-yfrac) +
                    + B * xfrac * (1.0f-yfrac) +
                    + C * yfrac * (1.0f-xfrac) +
                    + D * xfrac * yfrac);
      dst->data[k++] = gray;
    }
  }
}


int main(int argc, char** argv) {
  if (argc != 4) {
    printf("Usage: ./scale input.simple output.simple 0.5\n");
    return EXIT_FAILURE;
  }
  char* src_file = argv[1];
  char* dst_file = argv[2];
  float scale_factor = atof(argv[3]);

  SIMPLE_Image* src = SIMPLE_open(src_file);
  if (src == NULL) {
    return EXIT_FAILURE;
  }
  SIMPLE_Image* dst = SIMPLE_new(
      src->width * scale_factor,
      src->height * scale_factor);

  scale(src, dst, scale_factor);

  int status = SIMPLE_save(dst, dst_file);
  SIMPLE_destroy(src);
  SIMPLE_destroy(dst);
  return status;
}
