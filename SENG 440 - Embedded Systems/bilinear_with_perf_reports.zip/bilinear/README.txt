Hi Nick,

I have added things You were asking which is:
# 1. Placing particular scale() function reimplementation into separate source file
# 2. Adding Assembly file with each particular scale() implementation
# 3. Adding profiling reports for each scale() implementation called perf_scale*.txt
# 4. Updated Makefile that builds every scale() implementation
# 5. Added short and simple profile.sh script that automates building, profiling and reporting

I don't have /usr/bin/time command on this custom Odroid XU4 board and so I'm unable to collect memory resource consumption.

All measurementa where done using Odroid XU4 dev board on Cortex-A7 core with FPU and NEON engine.
File perf_summary.txt gathers cycle count numbers for each implemention of scale() function.
You will see that (un)suprisingly NEON version isn't necessarily the fastest one. We must take into account few things here:
1. Like I said before, bilinear interpolation algorithm, especially Your 8-bit greyscale version is not a good fit for NEON registers and instructions. To benefit from NEON we should have such data processing that's done on independent continuous region of memory. Of course there are numerous implementations of bilinear interpolation done using NEON instruction but they mostly operate on full RGB bytes (which can be loaded directly to into seperate NEON vectors and processed )
2. NEON registers are 128 bit long and do not support such as int8x4_t and therefore we couldn't read data[] directly because we need to first extract bytes and put them into separate NEON vectors which obviously takes more time.
3. Cores such as ARM Cortex-A7 on odroid XU4 do have NEON engine and hardware support
for floating point numbers and so they are nothing alike S3C440A and so final values can be quite different on other CPU.
4. C toolchains are getting better and better and they use extensively all possible hardware instruction such as NEON, FPU etc. In this project and hardware used we see that the fastest implementation is the one I wrote as scale_fixed scalar_opt.c. Apparently GCC produces faster NEON code that I was able to write. That's why it's better to write few different implementations and see which one is faster.
5. Exploring toolchain flags is a good practice to make best optimization setup. You see that there are executables with "*_o3" that have been produced by optimized compiler. We can see that most of values are 30-40% better than without this flag. However we must be aware that such aggressive optimization made by toolchain may decrease precision of calculations. Additionally, the code compiled with -O3 is impossible to debug as the order of executed instructions differs.
