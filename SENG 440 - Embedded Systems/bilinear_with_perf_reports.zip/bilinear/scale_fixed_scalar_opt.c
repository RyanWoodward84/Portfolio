
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "simple.h"

/*
This implemation behaves exactly like previous one BUT the main
optimizaton here was to remove unnecessarry shifting by Q_BITS.
One good optimization here was to tune Q_BITS in order to allow
chained multiplication without additional shifting. 
In this algorithm follwing multiplication chain is the longest:
A * i_xfrac * i_yfrac
It is dictating maximum Q_BITS value to allow 3 multiplication in a row without shifting back and forth. 
There are 3 multiplication and the result cannot exceed 32 bits. We know that A,B,C,D will not be higher than 255.
So the biggest number X that will satisfy equation (255 * X * X < 2^32) is 2048.
Therefore 2048 will be our fractional scale. Higher number might produce overflow,
lower number will decreace accuracy.
*/

#define Q_BITS (11u)
#define Q_MAX ((uint32_t)(1<<Q_BITS))
#define Q_FLOAT_TO_FIXED(a) ((uint32_t)((float)a*Q_MAX))
#define Q_10 Q_MAX

void scale(SIMPLE_Image* src, SIMPLE_Image* dst, float scale_factor)
{
  uint32_t i = dst->height, k = dst->height*dst->width-1;
  uint32_t j;
  // float scale = 1.0f / scale_factor;
  uint32_t scale = Q_FLOAT_TO_FIXED(1.0f / scale_factor);

  while(i--)
  {
    // uint32_t y = (uint32_t)(scale * i);
    uint32_t y = (scale * i) >> Q_BITS;
    // float yfrac = scale * i - y;
    uint32_t yfrac = (scale * i) - (y << Q_BITS);
    // float i_yfrac = 1.0f - yfrac;
    uint32_t i_yfrac = Q_10 - yfrac;
    j = dst->width;

    while(j--)
    {
      // uint32_t x = (uint32_t)(scale * j);
      uint32_t x = (scale * j) >> Q_BITS;
      // float xfrac = scale * j - x;
      uint32_t xfrac = (scale * j) - (x << Q_BITS);

      // float i_xfrac = 1.0f - xfrac;
      uint32_t i_xfrac = Q_10 - xfrac;

      uint32_t index = x + y * src->width;

      uint32_t A = src->data[index];
      uint32_t B = src->data[index + 1];
      uint32_t C = src->data[index + src->width];
      uint32_t D = src->data[index + src->width + 1];

      // uint32_t gray = (uint32_t)(A * i_xfrac * i_yfrac +
      //               + B * xfrac * i_yfrac +
      //               + C * yfrac * i_xfrac +
      //               + D * xfrac * yfrac);
      uint32_t gray = (uint32_t)(A * i_xfrac * i_yfrac +
                    + B * xfrac * i_yfrac +
                    + C * yfrac * i_xfrac +
                    + D * xfrac * yfrac) >> (Q_BITS+Q_BITS);
      dst->data[k--] = (uint8_t)gray;
    }
  }
}


int main(int argc, char** argv) {
  if (argc != 4) {
    printf("Usage: ./scale input.simple output.simple 0.5\n");
    return EXIT_FAILURE;
  }
  char* src_file = argv[1];
  char* dst_file = argv[2];
  float scale_factor = atof(argv[3]);

  SIMPLE_Image* src = SIMPLE_open(src_file);
  if (src == NULL) {
    return EXIT_FAILURE;
  }
  SIMPLE_Image* dst = SIMPLE_new(
      src->width * scale_factor,
      src->height * scale_factor);

  scale(src, dst, scale_factor);

  int status = SIMPLE_save(dst, dst_file);
  SIMPLE_destroy(src);
  SIMPLE_destroy(dst);
  return status;
}
