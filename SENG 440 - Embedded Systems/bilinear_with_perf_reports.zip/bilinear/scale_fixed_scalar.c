
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "simple.h"

/*
Since S3C440A CPU does not have any SIMD extension, we cannot perform any vectorized implementaion
using NEON. We can only perform such optimization which will reduce numbers of instruction exectured,
replace inefficient instruction with their efficient version or reduce memory usage to decrease cache miss rate.
*/

/*
Since S3C440A does not have a floating-point unit, we should avoid any
floating point calculation since they won't have any hardware acceleration.
Therefore we need to make all calculation on integer values.
In order to perform correctly fractional calculations on integer values,
we implement them using fixed-point calculation. Good and simple explanation
is here:
https://spin.atomicobject.com/2012/03/15/simple-fixed-point-math/

I have introduced new type called tQfract which will hold fractional
value represented by integer value. I also added basic operations on this type.
In order to mix fractional values and non-fractional values, I added conversions
between plain integer and fractional (represented by integer).

Value of Q_BITS must be high enough to maintain proper accuracy during calculation
but low enough to prevent from any overflow during multiplication.
*/

typedef uint32_t tQfract;
#define Q_BITS (16u)
#define Q_MAX ((tQfract)(1<<Q_BITS))
#define Q_FLOAT_TO_FIXED(a) ((tQfract)((float)a*Q_MAX))
#define Q_INT_TO_FRACT(a) ((tQfract)((a)<<Q_BITS))
#define Q_FRACT_TO_INT(a) ((uint32_t)((a)>>Q_BITS))
#define Q_ADD(a,b) ((tQfract)(a)+(b))
#define Q_SUB(a,b) ((tQfract)(a)-(b))
#define Q_MUL(a,b) ((tQfract)(((uint64_t)a)*(b) >> Q_BITS))
#define Q_DOT4(a,b,c,d) ((tQfract)(a)+(b)+(c)+(d))
#define Q_10 Q_MAX

void scale(SIMPLE_Image* src, SIMPLE_Image* dst, float scale_factor)
{
  uint32_t i = dst->height, k = dst->height*dst->width-1;
  uint32_t j;
  // float scale = 1.0f / scale_factor;
  uint32_t scale = Q_FLOAT_TO_FIXED(1.0f / scale_factor);

  while(i--)
  {
    // uint32_t y = (uint32_t)(scale * i);
    uint32_t y = Q_FRACT_TO_INT(Q_MUL(scale, Q_INT_TO_FRACT(i)));
    // float yfrac = scale * i - y;
    tQfract yfrac = Q_SUB(Q_MUL(scale, Q_INT_TO_FRACT(i)), Q_INT_TO_FRACT(y));
    j = dst->width;

    while(j--)
    {
      // uint32_t x = (uint32_t)(scale * j);
      uint32_t x = Q_FRACT_TO_INT(Q_MUL(scale, Q_INT_TO_FRACT(j)));
      // float xfrac = scale * j - x;
      tQfract xfrac = Q_SUB(Q_MUL(scale, Q_INT_TO_FRACT(j)), Q_INT_TO_FRACT(x));

      // float i_xfrac = 1.0f - xfrac;
      tQfract i_xfrac = Q_SUB(Q_10, xfrac);
      // float i_yfrac = 1.0f - yfrac;
      tQfract i_yfrac = Q_SUB(Q_10, yfrac);
      uint32_t index = x + y * src->width;

      uint32_t A = src->data[index];
      uint32_t B = src->data[index + 1];
      uint32_t C = src->data[index + src->width];
      uint32_t D = src->data[index + src->width + 1];

      // uint32_t gray = (uint32_t)(A * i_xfrac * i_yfrac +
      //               + B * xfrac * i_yfrac +
      //               + C * yfrac * i_xfrac +
      //               + D * xfrac * yfrac);
      uint32_t gray =  Q_FRACT_TO_INT(
                         Q_DOT4(
                           Q_MUL(Q_INT_TO_FRACT(A), Q_MUL(i_xfrac, i_yfrac))
                         , Q_MUL(Q_INT_TO_FRACT(B), Q_MUL(xfrac, i_yfrac))
                         , Q_MUL(Q_INT_TO_FRACT(C), Q_MUL(yfrac, i_xfrac)) 
                         , Q_MUL(Q_INT_TO_FRACT(D), Q_MUL(xfrac, yfrac))
                         )
                       );
      dst->data[k--] = (uint8_t)gray;
    }
  }
}

int main(int argc, char** argv) {
  if (argc != 4) {
    printf("Usage: ./scale input.simple output.simple 0.5\n");
    return EXIT_FAILURE;
  }
  char* src_file = argv[1];
  char* dst_file = argv[2];
  float scale_factor = atof(argv[3]);

  SIMPLE_Image* src = SIMPLE_open(src_file);
  if (src == NULL) {
    return EXIT_FAILURE;
  }
  SIMPLE_Image* dst = SIMPLE_new(
      src->width * scale_factor,
      src->height * scale_factor);

  scale(src, dst, scale_factor);

  int status = SIMPLE_save(dst, dst_file);
  SIMPLE_destroy(src);
  SIMPLE_destroy(dst);
  return status;
}
