#!/usr/bin/env bash

make clean
make all

rm perf_*
rm *.i
rm *.o

TARGETS=( scale_ref scale_naive scale_float_scalar_opt scale_fixed_scalar scale_fixed_neon scale_ref_o3 scale_naive_o3 scale_float_scalar_opt_o3 scale_fixed_scalar_o3 scale_fixed_scalar_opt_o3 scale_fixed_neon_o3 )

for target in "${TARGETS[@]}"
do
    perf record -e "cpu-cycles" taskset -c 1 ./bin/$target images/simple/pigs.simple  images/simple/pigs_20.simple 2.0
    perf report --header > perf_$target.txt
done

grep "Event count" -R ./perf_* > perf_summary.txt
cat perf_summary.txt

