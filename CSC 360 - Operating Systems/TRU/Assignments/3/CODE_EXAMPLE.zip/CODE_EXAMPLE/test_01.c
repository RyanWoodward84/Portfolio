#include <stdio.h>
#include <stdlib.h>

int main( void) {
  char x1, x2;
  register char c1 = 113, c2 = -98;
  register int temp1, temp2, temp_sum;
  register short int sum;

  printf( "x1 = ");
  scanf( "%hhi", &x1);
  printf( "x2 = ");
  scanf( "%hhi", &x2);

  temp1 = c1 * x1;
  temp2 = c2 * x2;
  temp_sum = temp1 + temp2;
  sum = (short int)(temp_sum >> 1);

  printf( "y = %hi\n", sum);
  return 0;
}
