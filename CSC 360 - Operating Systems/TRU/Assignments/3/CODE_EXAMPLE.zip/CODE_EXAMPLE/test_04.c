#include <stdio.h>
#include <stdlib.h>

#define N 8

int main( void) {
  int i;
  int xi[N>>2];
  int ci[N>>2] = { (113 << 24) | (-97 << 16) | (23 << 8) | (-55), 
                   (102 << 24) | (-102 << 16) | (38 << 8) | (-62)};
  char *x;
  char *c;
  register int temp_x1, temp_x2, temp;
  register short int sum;

  x = (char *)xi;  
  c = (char *)ci;
  
  for( i=0; i<N; i++) {
    printf( "x[%i] = ", i);
    scanf( "%hhi", &x[i]);
  }

  temp = 0;
    temp_x1 = xi[0];
    temp_x2 = xi[1];
    __asm__ __volatile__ (
      "sima\t%0, %1, %2\n"
      : "=r" (temp)
      : "r" (temp_x1), "r" (temp_x2)
    );

  sum = (short int)(temp >> 3);

  printf( "y = %hi\n", sum);
  return 0;
}
