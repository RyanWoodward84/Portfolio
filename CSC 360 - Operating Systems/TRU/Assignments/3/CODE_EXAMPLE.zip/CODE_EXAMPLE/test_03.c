#include <stdio.h>
#include <stdlib.h>

#define N 8

int main( void) {
  int i;
  int xi[N>>2];
  int ci[N>>2] = { (113 << 24) | (-97 << 16) | (23 << 8) | (-55), 
                   (102 << 24) | (-102 << 16) | (38 << 8) | (-62)};
  char *x;
  char *c;
  register char x0, x1, x2, x3, c0, c1, c2, c3;
  int temp_x, temp_c, temp, temp_sum;
  register short int sum;

  x = (char *)xi;  
  c = (char *)ci;
  
  for( i=0; i<N; i++) {
    printf( "x[%i] = ", i);
    scanf( "%hhi", &x[i]);
  }

  temp = 0;
  for( i=0; i<N/4; i+=1) {
    temp_x = xi[i];
    temp_c = ci[i];
    x0 = (char)((temp_x >> 24) & 0xff);
    x1 = (char)((temp_x >> 16) & 0xff);
    x2 = (char)((temp_x >> 8) & 0xff);
    x3 = (char)((temp_x) & 0xff);
    c0 = (char)((temp_c >> 24) & 0xff);
    c1 = (char)((temp_c >> 16) & 0xff);
    c2 = (char)((temp_c >> 8) & 0xff);
    c3 = (char)((temp_c) & 0xff);
    temp += (int)c0 * (int)x0 + (int)c1 * (int)x1 +
            (int)c2 * (int)x2 + (int)c3 * (int)x3;
  }

  sum = (short int)(temp >> 3);

  printf( "y = %hi\n", sum);
  return 0;
}
