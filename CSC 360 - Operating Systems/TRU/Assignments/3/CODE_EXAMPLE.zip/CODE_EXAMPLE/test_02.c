#include <stdio.h>
#include <stdlib.h>

#define N 8

int main( void) {
  int i;
  char x[N];
  char c[N] = {113, -97, 23, -55, 102, -102, 38, -62};
  int temp, temp_sum;
  register short int sum;

  for( i=0; i<N; i++) {
    printf( "x[%i] = ", i);
    scanf( "%hhi", &x[i]);
  }

  temp = 0;
  for( i=0; i<N; i++) {
    temp += (int)c[i] * (int)x[i];
  }

  sum = (short int)(temp >> 3);

  printf( "y = %hi\n", sum);
  return 0;
}
